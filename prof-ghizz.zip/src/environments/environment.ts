export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCQgTWYANjjhTl5n3se4MLhYAkGX_um2ag",
    authDomain: "gymcardsapp.firebaseapp.com",
    projectId: "gymcardsapp",
    // Correzione: bucket Storage deve essere del tipo <project>.appspot.com
    storageBucket: "gymcardsapp.appspot.com",
    messagingSenderId: "30373311778",
    appId: "1:30373311778:web:d599488bdb7feda34f617b",
    measurementId: "G-3CM91FP0WL"
  }
};