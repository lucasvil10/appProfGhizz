import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { Subscription } from 'rxjs';

// MODULAR AngularFire imports (no compat)
import { Firestore, collection, collectionData, doc, setDoc, updateDoc, deleteDoc } from '@angular/fire/firestore';
import { Storage, ref, uploadBytes, getDownloadURL } from '@angular/fire/storage';

interface User {
  id: string; // Firestore usa gli ID stringa
  name: string;
  email: string;
  signupDate: string;
  status: string;
  phone?: string;
  avatarUrl?: string;
}

@Component({
  selector: 'app-anagrafica',
  templateUrl: './anagrafica.component.html',
  styleUrls: ['./anagrafica.component.css']
})
export class AnagraficaComponent implements OnInit, OnDestroy {
  // Inject modular services
  private firestore = inject(Firestore);
  private storage = inject(Storage);

  users: User[] = [];
  filteredUsers: User[] = [];
  searchTerm: string = '';

  showFilters = false;
  filterStatus: string = '';
  filterHasEmail: string = '';

  modalOpen = false;

  avatarLoading: boolean = false;
  loading: boolean = false;
  errorMsg: string = '';

  private usersSub?: Subscription;

  form = {
    nome: '',
    cognome: '',
    emailModal: '',
    phone: '',
    isActive: true,
    signupDateModal: '',
    avatar: ''
  };

  // Stato per edit utente
  editModalOpen = false;
  editUser?: User;
  editForm = {
    nome: '',
    cognome: '',
    email: '',
    phone: '',
    isActive: true,
    avatar: ''
  };
  editAvatarLoading = false;

  ngOnInit() {
    this.loadUsers();
  }

  ngOnDestroy(): void {
    this.usersSub?.unsubscribe();
  }

  loadUsers() {
    this.loading = true;
    this.errorMsg = '';
    this.usersSub?.unsubscribe();

    const usersCol = collection(this.firestore, 'users');
    this.usersSub = collectionData(usersCol, { idField: 'id' }).subscribe({
      next: (data) => {
        this.users = (data || []) as User[];
        this.applyFilters();
        this.loading = false;
      },
      error: (err) => {
        console.error('Errore caricamento utenti:', err);
        this.errorMsg = 'Impossibile caricare gli utenti. Riprova più tardi.';
        this.loading = false;
      }
    });
  }

  openModal() {
    this.resetForm();
    this.modalOpen = true;
  }

  closeModal() {
    this.modalOpen = false;
    this.resetForm();
  }

  triggerAvatarInput(input: HTMLInputElement) {
    input.click();
  }

  async onAvatarChange(event: any) {
    const file = event.target.files && event.target.files[0];
    if (file) {
      this.avatarLoading = true;
      try {
        const filePath = `avatars/${Date.now()}_${file.name}`;
        const storageRef = ref(this.storage, filePath);
        await uploadBytes(storageRef, file);
        const url = await getDownloadURL(storageRef);
        this.form.avatar = url || '';
      } catch (e) {
        console.error('Upload avatar fallito:', e);
        this.form.avatar = '';
      } finally {
        this.avatarLoading = false;
      }
    } else {
      this.form.avatar = '';
      this.avatarLoading = false;
    }
  }

  async registerUser() {
    // Validazioni base
    const fullName = `${this.form.nome} ${this.form.cognome}`.trim();
    if (!fullName) {
      this.errorMsg = 'Inserisci Nome e Cognome.';
      return;
    }
    if (this.form.emailModal && !this.form.emailModal.includes('@')) {
      this.errorMsg = 'Email non valida.';
      return;
    }

    const dt = this.form.signupDateModal
      ? this.form.signupDateModal.split('-').reverse().join('/')
      : new Date().toLocaleDateString('it-IT');

    // Genera un id documento
    const id = crypto.randomUUID();
    const newUser: User = {
      id,
      name: fullName,
      email: this.form.emailModal,
      phone: this.form.phone,
      signupDate: dt,
      status: this.form.isActive ? 'Attivo' : 'Inattivo',
      avatarUrl: this.form.avatar || undefined
    };

    try {
      const userDoc = doc(this.firestore, `users/${id}`);
      await setDoc(userDoc, newUser);
      this.closeModal();
      // la sottoscrizione aggiorna automaticamente users
    } catch (e) {
      console.error('Creazione utente fallita:', e);
      this.errorMsg = 'Errore durante la creazione utente.';
    }
  }

  resetForm() {
    this.form = {
      nome: '',
      cognome: '',
      emailModal: '',
      phone: '',
      isActive: true,
      signupDateModal: '',
      avatar: ''
    };
    this.avatarLoading = false;
    this.errorMsg = '';
  }

  onSearchChange() {
    this.applyFilters();
  }

  toggleFilters() {
    this.showFilters = !this.showFilters;
  }

  applyFilters() {
    let filtered = [...this.users];
    if (this.filterStatus) {
      filtered = filtered.filter(u => u.status === this.filterStatus);
    }
    if (this.filterHasEmail === 'with') {
      filtered = filtered.filter(u => u.email && u.email.trim().length > 0);
    } else if (this.filterHasEmail === 'without') {
      filtered = filtered.filter(u => !u.email || u.email.trim().length === 0);
    }
    const term = this.searchTerm.toLowerCase().trim();
    this.filteredUsers = filtered.filter(u =>
      (u.name || '').toLowerCase().includes(term) ||
      (u.email || '').toLowerCase().includes(term) ||
      (u.signupDate || '').toLowerCase().includes(term) ||
      (u.status || '').toLowerCase().includes(term)
    );
  }

  // ------- Edit utente ----------
  openEdit(user: User) {
    this.editUser = user;
    const parts = (user.name || '').trim().split(' ');
    this.editForm.nome = parts[0] || '';
    this.editForm.cognome = parts.slice(1).join(' ') || '';
    this.editForm.email = user.email || '';
    this.editForm.phone = user.phone || '';
    this.editForm.isActive = (user.status || 'Attivo') === 'Attivo';
    this.editForm.avatar = user.avatarUrl || '';
    this.editModalOpen = true;
    this.errorMsg = '';
  }

  closeEdit() {
    this.editModalOpen = false;
    this.editUser = undefined;
    this.editForm = {
      nome: '',
      cognome: '',
      email: '',
      phone: '',
      isActive: true,
      avatar: ''
    };
    this.editAvatarLoading = false;
    this.errorMsg = '';
  }

  triggerEditAvatarInput(input: HTMLInputElement) {
    input.click();
  }

  async onEditAvatarChange(event: any) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    this.editAvatarLoading = true;
    try {
      const filePath = `avatars/${Date.now()}_${file.name}`;
      const storageRef = ref(this.storage, filePath);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      this.editForm.avatar = url || '';
    } catch (e) {
      console.error('Upload avatar (edit) fallito:', e);
    } finally {
      this.editAvatarLoading = false;
    }
  }

  async saveEdit() {
    if (!this.editUser) return;
    const fullName = `${this.editForm.nome} ${this.editForm.cognome}`.trim();
    if (!fullName) {
      this.errorMsg = 'Inserisci Nome e Cognome.';
      return;
    }
    if (this.editForm.email && !this.editForm.email.includes('@')) {
      this.errorMsg = 'Email non valida.';
      return;
    }
    const patch: Partial<User> = {
      name: fullName,
      email: this.editForm.email || '',
      phone: this.editForm.phone || '',
      status: this.editForm.isActive ? 'Attivo' : 'Inattivo',
      avatarUrl: this.editForm.avatar || undefined
    };
    try {
      const userDoc = doc(this.firestore, `users/${this.editUser.id}`);
      await updateDoc(userDoc, patch as any);
      this.closeEdit();
      // la sottoscrizione aggiorna automaticamente users
    } catch (e) {
      console.error('Aggiornamento utente fallito:', e);
      this.errorMsg = 'Errore durante l’aggiornamento utente.';
    }
  }

  // ------- Delete utente ----------
  async deleteUser(user: User) {
    if (!confirm(`Eliminare l’utente "${user.name}"?`)) return;
    try {
      const userDoc = doc(this.firestore, `users/${user.id}`);
      await deleteDoc(userDoc);
      // la sottoscrizione aggiorna automaticamente users
    } catch (e) {
      console.error('Eliminazione utente fallita:', e);
      this.errorMsg = 'Errore durante l’eliminazione utente.';
    }
  }
}