import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { HeaderComponent } from './layout/header.component';
import { SidebarComponent } from './layout/sidebar.component';
import { HomeComponent } from './pages/home/home.component';
import { EserciziComponent } from './pages/esercizi/esercizi.component';
import { AnagraficaComponent } from './pages/anagrafica/anagrafica.component';
import { AnagraficaListComponent } from './pages/anagrafica-list/anagrafica-list.component';
import { AnagraficaDetailComponent } from './pages/anagrafica-detail/anagrafica-detail.component';
import { GestioneSchedeComponent } from './pages/gestione-schede/gestione-schede.component';
import { DettaglioEserciziComponent } from './pages/dettaglio-esercizi/dettaglio-esercizi.component';

import { environment } from '../environments/environment';

// API moderna di @angular/fire (modular)
import { provideFirebaseApp, initializeApp } from '@angular/fire/app';
import { provideAuth, getAuth } from '@angular/fire/auth';
import { provideFirestore, getFirestore } from '@angular/fire/firestore';
import { provideStorage, getStorage } from '@angular/fire/storage';
// Analytics è opzionale; funziona solo su HTTPS e con GA abilitato nel progetto
// Se stai sviluppando su http://localhost o Codespaces senza https, conviene commentarlo
import { provideAnalytics, getAnalytics, ScreenTrackingService, UserTrackingService } from '@angular/fire/analytics';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    HomeComponent,
    EserciziComponent,
    DettaglioEserciziComponent,
    AnagraficaComponent,
    AnagraficaListComponent,
    AnagraficaDetailComponent,
    GestioneSchedeComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    FormsModule,

    // Inizializzazione Firebase con config da environment
    provideFirebaseApp(() => initializeApp(environment.firebase)),
    provideAuth(() => getAuth()),
    provideFirestore(() => getFirestore()),
    provideStorage(() => getStorage()),
    // In sviluppo su http://localhost l'API Analytics può lanciare errori.
    // Se necessario, commenta la riga seguente in dev.
    // provideAnalytics(() => getAnalytics()),
  ],
  providers: [
    // Disabilitato per evitare errori in dev non-https
    // ScreenTrackingService,
    // UserTrackingService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}